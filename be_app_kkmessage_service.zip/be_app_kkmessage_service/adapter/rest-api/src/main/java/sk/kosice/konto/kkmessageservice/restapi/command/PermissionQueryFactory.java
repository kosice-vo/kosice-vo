package sk.kosice.konto.kkmessageservice.restapi.command;

import java.util.UUID;
import sk.kosice.konto.kkmessageservice.domain.permission.query.ImmutablePermissionListingQuery;
import sk.kosice.konto.kkmessageservice.domain.permission.query.PermissionListingQuery;

public class PermissionQueryFactory {

  public static PermissionListingQuery map(UUID userId) {
    return ImmutablePermissionListingQuery.builder().userId(userId).build();
  }
}
