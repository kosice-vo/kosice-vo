package sk.kosice.konto.kkmessageservice.restapi.common.enumeration;

public enum Platform {
  WEB,
  MOBILE,
  DESKTOP,
  SERVER
}
