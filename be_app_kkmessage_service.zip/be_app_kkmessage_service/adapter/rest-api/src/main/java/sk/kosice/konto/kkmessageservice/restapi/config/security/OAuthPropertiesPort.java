package sk.kosice.konto.kkmessageservice.restapi.config.security;

public interface OAuthPropertiesPort {

  String ocCitizenIssuerLocation();

  String ocCitizenJwksUrl();

  String ocEmployeeIssuerLocation();

  String ocEmployeeJwksUrl();

  String ocAppIntegrationIssuerLocation();

  String ocAppIntegrationJwksUrl();
}
