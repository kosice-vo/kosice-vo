package sk.kosice.konto.kkmessageservice.restapi.config.converter;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import sk.kosice.konto.kkmessageservice.restapi.common.enumeration.Platform;

@Component
public class PlatformEnumConverter implements Converter<String, Platform> {

  @Override
  public Platform convert(String source) {
    return Platform.valueOf(source.toUpperCase());
  }
}
