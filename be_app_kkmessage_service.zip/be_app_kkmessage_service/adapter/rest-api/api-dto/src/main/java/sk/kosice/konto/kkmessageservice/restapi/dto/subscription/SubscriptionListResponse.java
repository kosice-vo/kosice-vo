package sk.kosice.konto.kkmessageservice.restapi.dto.subscription;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.restapi.dto.common.listing.ListingResponse;

@JsonDeserialize(as = ImmutableSubscriptionListResponse.class)
@JsonSerialize(as = ImmutableSubscriptionListResponse.class)
@Value.Immutable
public interface SubscriptionListResponse extends ListingResponse<SubscriptionDetailResponse> {}
