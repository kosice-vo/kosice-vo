package sk.kosice.konto.kkmessageservice.restapi.dto.topic;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.restapi.dto.common.listing.ListingResponse;

@JsonDeserialize(as = ImmutableTopicListResponse.class)
@JsonSerialize(as = ImmutableTopicListResponse.class)
@Value.Immutable
public interface TopicListResponse extends ListingResponse<TopicDetailResponse> {}
