package sk.kosice.konto.kkmessageservice.restapi.dto.subscription;

import java.util.UUID;

public record BaseTopic(UUID id, String name, String description) {}
