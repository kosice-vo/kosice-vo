package sk.kosice.konto.kkmessageservice.restapi.dto.subscription;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.util.UUID;
import org.immutables.value.Value;

@JsonSerialize(as = ImmutableSubscriptionDetailResponse.class)
@JsonDeserialize(as = ImmutableSubscriptionDetailResponse.class)
@Value.Immutable
public interface SubscriptionDetailResponse extends BaseSubscriptionDto {

  UUID getRecipientKid();

  BaseTopic getTopic();

  BaseOrganization getOrganization();
}
