package sk.kosice.konto.kkmessageservice.restapi.dto.message;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.restapi.dto.common.listing.ListingResponse;

@JsonDeserialize(as = ImmutableMessageWithKidListResponse.class)
@JsonSerialize(as = ImmutableMessageWithKidListResponse.class)
@Value.Immutable
public interface MessageWithKidListResponse extends ListingResponse<BaseMessageWithKidDto> {}
