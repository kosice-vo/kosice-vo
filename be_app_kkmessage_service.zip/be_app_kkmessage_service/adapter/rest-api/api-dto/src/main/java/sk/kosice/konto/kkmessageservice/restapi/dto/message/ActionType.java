package sk.kosice.konto.kkmessageservice.restapi.dto.message;

public enum ActionType {
  OPEN_URL,
  OPEN_PAY_BY_CARD_URL,
  SHOW_PAY_QR_CODE
}
