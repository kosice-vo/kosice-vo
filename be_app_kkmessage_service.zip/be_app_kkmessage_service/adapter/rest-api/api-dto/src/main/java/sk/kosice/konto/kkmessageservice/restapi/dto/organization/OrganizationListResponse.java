package sk.kosice.konto.kkmessageservice.restapi.dto.organization;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import org.immutables.value.Value;

@JsonSerialize(as = ImmutableOrganizationListResponse.class)
@JsonDeserialize(as = ImmutableOrganizationListResponse.class)
@Value.Immutable
public interface OrganizationListResponse {

  @Schema(requiredMode = Schema.RequiredMode.REQUIRED)
  List<OrganizationDto> items();
}
