package sk.kosice.konto.kkmessageservice.restapi.dto.topic;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.immutables.value.Value;

@JsonDeserialize(as = ImmutableTopicCreateRequest.class)
@JsonSerialize(as = ImmutableTopicCreateRequest.class)
@Value.Immutable
public interface TopicCreateRequest extends BaseTopicDto {}
