package sk.kosice.konto.kkmessageservice.restapi.dto.message;

public enum ActionPayMetadataType {
  TEXT,
  PRICE,
  IBAN,
  VARIABLE_SYMBOL,
  CONSTANT_SYMBOL,
  SPECIFIC_SYMBOL
}
