package sk.kosice.konto.kkmessageservice.restapi.dto.subscription;

import java.util.UUID;

public record BaseOrganization(UUID id, String name) {}
