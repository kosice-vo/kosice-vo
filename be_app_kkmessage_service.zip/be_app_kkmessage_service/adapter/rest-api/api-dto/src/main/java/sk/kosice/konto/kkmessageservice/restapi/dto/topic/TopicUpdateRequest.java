package sk.kosice.konto.kkmessageservice.restapi.dto.topic;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.immutables.value.Value;

@JsonDeserialize(as = ImmutableTopicUpdateRequest.class)
@JsonSerialize(as = ImmutableTopicUpdateRequest.class)
@Value.Immutable
public interface TopicUpdateRequest extends BaseTopicDto {}
