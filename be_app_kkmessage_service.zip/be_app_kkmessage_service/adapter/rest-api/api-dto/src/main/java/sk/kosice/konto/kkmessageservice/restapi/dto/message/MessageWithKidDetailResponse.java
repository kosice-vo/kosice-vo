package sk.kosice.konto.kkmessageservice.restapi.dto.message;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.immutables.value.Value;

@JsonDeserialize(as = ImmutableMessageWithKidDetailResponse.class)
@JsonSerialize(as = ImmutableMessageWithKidDetailResponse.class)
@Value.Immutable
public interface MessageWithKidDetailResponse
    extends BaseMessageWithKidDto, MessageDetailResponse {}
