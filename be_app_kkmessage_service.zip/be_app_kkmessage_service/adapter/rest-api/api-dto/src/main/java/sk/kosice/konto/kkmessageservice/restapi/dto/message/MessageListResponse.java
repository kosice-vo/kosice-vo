package sk.kosice.konto.kkmessageservice.restapi.dto.message;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.restapi.dto.common.listing.ListingResponse;

@JsonDeserialize(as = ImmutableMessageListResponse.class)
@JsonSerialize(as = ImmutableMessageListResponse.class)
@Value.Immutable
public interface MessageListResponse extends ListingResponse<BaseMessageDto> {}
