package sk.kosice.konto.kkmessageservice.idp;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@SpringBootApplication(scanBasePackageClasses = SpringAzureIdpTestApp.class)
@ActiveProfiles("test")
public abstract class SpringAzureIdpTestApp {}
