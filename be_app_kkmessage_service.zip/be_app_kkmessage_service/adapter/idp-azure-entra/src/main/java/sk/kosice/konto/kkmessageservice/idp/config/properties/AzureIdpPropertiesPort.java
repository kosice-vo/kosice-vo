package sk.kosice.konto.kkmessageservice.idp.config.properties;

public interface AzureIdpPropertiesPort {

  String tenantId();

  String clientId();

  String clientSecret();

  String scopes();
}
