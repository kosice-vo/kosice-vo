package sk.kosice.konto.kkmessageservice.repository.recipient;

import sk.kosice.konto.kkmessageservice.repository.JooqRepositoryTest;

public abstract class JooqRecipientRepositoryTest extends JooqRepositoryTest
    implements JooqRecipientRepositoryTestSupport {}
