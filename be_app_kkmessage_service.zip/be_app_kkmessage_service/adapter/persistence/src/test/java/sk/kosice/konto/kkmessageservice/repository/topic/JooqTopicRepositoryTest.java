package sk.kosice.konto.kkmessageservice.repository.topic;

import sk.kosice.konto.kkmessageservice.repository.JooqRepositoryTest;

public class JooqTopicRepositoryTest extends JooqRepositoryTest
    implements JooqTopicRepositoryTestSupport {}
