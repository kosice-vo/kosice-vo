package sk.kosice.konto.kkmessageservice.repository.message;

import sk.kosice.konto.kkmessageservice.repository.JooqRepositoryTest;
import sk.kosice.konto.kkmessageservice.repository.recipient.JooqRecipientRepositoryTestSupport;

public abstract class JooqMessageRepositoryTest extends JooqRepositoryTest
    implements JooqMessageRepositoryTestSupport, JooqRecipientRepositoryTestSupport {}
