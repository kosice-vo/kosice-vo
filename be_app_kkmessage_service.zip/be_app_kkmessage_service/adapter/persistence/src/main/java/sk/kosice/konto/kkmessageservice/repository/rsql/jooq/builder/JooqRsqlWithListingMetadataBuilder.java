package sk.kosice.konto.kkmessageservice.repository.rsql.jooq.builder;

import sk.kosice.konto.kkmessageservice.repository.rsql.jooq.metadata.JooqRsqlMetadata;

public abstract class JooqRsqlWithListingMetadataBuilder<T>
    implements JooqRsqlListingMetadataAwareBuilder<T> {

  private JooqRsqlMetadata metadata;

  @Override
  public void setJooqRsqlMetadata(JooqRsqlMetadata metadata) {
    this.metadata = metadata;
  }

  protected JooqRsqlMetadata getMetadata() {
    return metadata;
  }
}
