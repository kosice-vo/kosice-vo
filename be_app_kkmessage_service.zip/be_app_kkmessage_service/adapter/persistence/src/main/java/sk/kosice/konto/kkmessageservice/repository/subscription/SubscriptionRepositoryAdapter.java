package sk.kosice.konto.kkmessageservice.repository.subscription;

import sk.kosice.konto.kkmessageservice.business.subscription.port.outbound.PersistSubscriptionPort;
import sk.kosice.konto.kkmessageservice.business.subscription.port.outbound.QuerySubscriptionPort;

public interface SubscriptionRepositoryAdapter
    extends PersistSubscriptionPort, QuerySubscriptionPort {}
