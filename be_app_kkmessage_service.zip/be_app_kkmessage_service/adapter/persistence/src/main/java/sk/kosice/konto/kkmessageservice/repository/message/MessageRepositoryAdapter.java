package sk.kosice.konto.kkmessageservice.repository.message;

import sk.kosice.konto.kkmessageservice.business.message.port.outbound.PersistMessagePort;
import sk.kosice.konto.kkmessageservice.business.message.port.outbound.QueryMessagePort;

public interface MessageRepositoryAdapter extends PersistMessagePort, QueryMessagePort {}
