package sk.kosice.konto.kkmessageservice.repository.rsql.jooq.metadata;

import org.jooq.Condition;
import org.jooq.JoinType;

public interface JooqRsqlMetadataOnStep {

  JooqRsqlMetadata joinOn(Condition condition);

  JooqRsqlMetadata joinOn(Condition condition, JoinType type);
}
