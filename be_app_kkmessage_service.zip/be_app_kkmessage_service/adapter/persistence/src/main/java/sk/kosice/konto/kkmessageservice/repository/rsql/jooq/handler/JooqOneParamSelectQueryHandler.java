package sk.kosice.konto.kkmessageservice.repository.rsql.jooq.handler;

public interface JooqOneParamSelectQueryHandler<T> extends JooqSelectQueryHandler<T, T> {}
