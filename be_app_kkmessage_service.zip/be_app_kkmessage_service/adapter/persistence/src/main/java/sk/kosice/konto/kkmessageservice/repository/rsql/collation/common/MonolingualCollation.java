package sk.kosice.konto.kkmessageservice.repository.rsql.collation.common;

import com.neovisionaries.i18n.LanguageCode;
import org.jooq.Field;

public interface MonolingualCollation {

  Field<?> getCollatedAttribute(Field<?> field, String language);

  String getCollation(LanguageCode languageCode);
}
