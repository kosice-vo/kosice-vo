package sk.kosice.konto.kkmessageservice.repository.rsql.jooq.handler;

public interface JooqSelectQueryHandler<T, R> {

  R handle(T query);
}
