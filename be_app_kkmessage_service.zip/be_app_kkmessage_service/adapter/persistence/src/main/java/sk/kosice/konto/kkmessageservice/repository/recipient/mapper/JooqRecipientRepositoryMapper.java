package sk.kosice.konto.kkmessageservice.repository.recipient.mapper;

import org.jooq.RecordMapper;
import sk.kosice.konto.kkmessageservice.domain.recipient.entity.ImmutableRecipientEntity;
import sk.kosice.konto.kkmessageservice.domain.recipient.entity.RecipientEntity;
import sk.kosice.konto.kkmessageservice.repository.model.tables.records.RecipientRecord;

public final class JooqRecipientRepositoryMapper {

  public static RecordMapper<RecipientRecord, RecipientEntity> recipientRecordMapper() {
    return record ->
        ImmutableRecipientEntity.builder().kid(record.getKid()).email(record.getEmail()).build();
  }
}
