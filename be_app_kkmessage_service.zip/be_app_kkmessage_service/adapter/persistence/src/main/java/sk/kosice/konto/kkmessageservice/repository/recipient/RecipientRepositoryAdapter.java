package sk.kosice.konto.kkmessageservice.repository.recipient;

import sk.kosice.konto.kkmessageservice.business.recipient.port.outbound.PersistRecipientPort;
import sk.kosice.konto.kkmessageservice.business.recipient.port.outbound.QueryRecipientPort;

public interface RecipientRepositoryAdapter extends PersistRecipientPort, QueryRecipientPort {}
