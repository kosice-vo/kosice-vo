package sk.kosice.konto.kkmessageservice.repository.rsql.jooq.metadata;

public interface JooqRsqlMetadataAware {

  void setJooqRsqlMetadata(JooqRsqlMetadata metadata);
}
