package sk.kosice.konto.kkmessageservice.repository.rsql.jooq.handler;

import sk.kosice.konto.kkmessageservice.repository.rsql.jooq.metadata.JooqRsqlMetadata;
import sk.kosice.konto.kkmessageservice.repository.rsql.jooq.metadata.JooqRsqlMetadataConfigProvider;

public class DummyJooqRsqlMetadataConfigProvider implements JooqRsqlMetadataConfigProvider {

  @Override
  public void configure(JooqRsqlMetadata metadata) {}
}
