package sk.kosice.konto.kkmessageservice.repository.topic;

import sk.kosice.konto.kkmessageservice.business.topic.port.outbound.PersistTopicPort;
import sk.kosice.konto.kkmessageservice.business.topic.port.outbound.QueryTopicPort;

public interface TopicRepositoryAdapter extends PersistTopicPort, QueryTopicPort {}
