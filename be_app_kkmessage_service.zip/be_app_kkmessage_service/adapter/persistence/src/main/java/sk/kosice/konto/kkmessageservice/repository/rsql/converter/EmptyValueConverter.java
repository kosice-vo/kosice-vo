package sk.kosice.konto.kkmessageservice.repository.rsql.converter;

public class EmptyValueConverter implements FieldValueConverter<String> {

  @Override
  public boolean isAccessibleFor(Class clazz) {
    return true;
  }

  @Override
  public String from(String from) {
    return from;
  }
}
