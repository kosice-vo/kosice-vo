package sk.kosice.konto.kkmessageservice.repository.rsql;

import cz.jirutka.rsql.parser.ast.Node;

public interface RsqlNodeParser<T> {

  T parse(Node node);
}
