package sk.kosice.konto.kkmessageservice.repository.rsql.jooq.metadata;

public interface JooqRsqlMetadataConfigProvider {

  void configure(JooqRsqlMetadata metadata);
}
