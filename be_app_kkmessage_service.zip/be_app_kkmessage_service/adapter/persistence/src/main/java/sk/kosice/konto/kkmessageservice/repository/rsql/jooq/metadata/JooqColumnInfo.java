package sk.kosice.konto.kkmessageservice.repository.rsql.jooq.metadata;

import org.jooq.Field;
import sk.kosice.konto.kkmessageservice.repository.rsql.converter.FieldValueConverter;

public class JooqColumnInfo<T> {

  private Field<T> field;

  private FieldValueConverter<T> converter;

  public Field<T> getField() {
    return field;
  }

  public void setField(Field<T> field) {
    this.field = field;
  }

  public FieldValueConverter<T> getConverter() {
    return converter;
  }

  public void setConverter(FieldValueConverter<T> converter) {
    this.converter = converter;
  }
}
