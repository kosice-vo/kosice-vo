package sk.kosice.konto.kkmessageservice.repository.rsql.converter;

public interface FieldValueConverter<T> {

  boolean isAccessibleFor(Class clazz);

  T from(String from);
}
