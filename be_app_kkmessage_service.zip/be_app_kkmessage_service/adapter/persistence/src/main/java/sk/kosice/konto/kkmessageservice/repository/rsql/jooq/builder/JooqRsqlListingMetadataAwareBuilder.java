package sk.kosice.konto.kkmessageservice.repository.rsql.jooq.builder;

import sk.kosice.konto.kkmessageservice.repository.rsql.RsqlNodeBuilder;
import sk.kosice.konto.kkmessageservice.repository.rsql.jooq.metadata.JooqRsqlMetadataAware;

public interface JooqRsqlListingMetadataAwareBuilder<T>
    extends RsqlNodeBuilder<T>, JooqRsqlMetadataAware {}
