package sk.kosice.konto.kkmessageservice.domain.common.enumeration;

public enum Role {
  ADMIN("Admin"),
  ADMIN_GLOBAL("Admin-Global");

  private final String name;

  Role(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }
}
