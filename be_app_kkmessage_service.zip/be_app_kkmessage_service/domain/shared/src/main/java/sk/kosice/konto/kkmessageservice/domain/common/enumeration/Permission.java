package sk.kosice.konto.kkmessageservice.domain.common.enumeration;

import java.util.List;

public enum Permission {
  ACTION_MANAGE_MESSAGE(Role.ADMIN, Role.ADMIN_GLOBAL),
  ACTION_MANAGE_TOPIC(Role.ADMIN_GLOBAL);

  private final List<Role> roles;

  Permission(Role... roles) {
    this.roles = List.of(roles);
  }

  public List<Role> getRoles() {
    return roles;
  }
}
