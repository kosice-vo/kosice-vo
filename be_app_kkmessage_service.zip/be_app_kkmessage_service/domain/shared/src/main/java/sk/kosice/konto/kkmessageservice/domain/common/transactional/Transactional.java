package sk.kosice.konto.kkmessageservice.domain.common.transactional;

import java.util.function.Supplier;

public interface Transactional {

  <V> V result(Supplier<V> transactionalCall);

  <V> V result(Supplier<V> transactionalCall, Supplier<V> rollbackCall);
}
