package sk.kosice.konto.kkmessageservice.domain.common.enumeration;

public enum BodyType {
  TEXT,
  HTML,
  FORMATTED
}
