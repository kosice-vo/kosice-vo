package sk.kosice.konto.kkmessageservice.domain.common;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;

public final class TimeProvider {

  public static final ZoneOffset ZONE = ZoneOffset.UTC;

  public static OffsetDateTime offsetNow() {
    return OffsetDateTime.now(ZONE);
  }
}
