@Value.Style(stagedBuilder = true)
package sk.kosice.konto.kkmessageservice;

import org.immutables.value.Value;
