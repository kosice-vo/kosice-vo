package sk.kosice.konto.kkmessageservice.domain.subscription.command;

import java.util.UUID;
import org.immutables.value.Value;

@Value.Immutable
public interface UpdateSubscriptionCommand extends BaseSubscriptionCommand {

  UUID recipientKid();
}
