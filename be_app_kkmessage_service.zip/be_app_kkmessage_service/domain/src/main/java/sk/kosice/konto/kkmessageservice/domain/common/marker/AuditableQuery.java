package sk.kosice.konto.kkmessageservice.domain.common.marker;

import java.util.Optional;
import sk.kosice.konto.kkmessageservice.domain.common.audit.ActorIdentity;

public interface AuditableQuery extends Query {

  /**
   * Identity of logged person who performed action.
   *
   * @return Identity of actor.
   */
  Optional<ActorIdentity> actorId();
}
