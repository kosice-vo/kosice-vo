package sk.kosice.konto.kkmessageservice.domain.subscription.command;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.marker.Command;

@Value.Immutable
public abstract class SubscriptionInitializationForRecipientCommand implements Command {

  @Value.Parameter
  public abstract UUID recipientKid();
}
