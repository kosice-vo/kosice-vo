package sk.kosice.konto.kkmessageservice.domain.common.audit;

import org.immutables.value.Value;

@Value.Immutable
public abstract class ActorIdentity {

  @Value.Parameter
  public abstract String id();
}
