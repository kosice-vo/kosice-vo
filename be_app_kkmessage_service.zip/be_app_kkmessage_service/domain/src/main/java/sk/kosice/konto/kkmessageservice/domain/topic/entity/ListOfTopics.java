package sk.kosice.konto.kkmessageservice.domain.topic.entity;

import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.listing.PaginatedResult;

@Value.Immutable
public interface ListOfTopics extends PaginatedResult<TopicEntity> {}
