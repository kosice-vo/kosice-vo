package sk.kosice.konto.kkmessageservice.domain.subscription.entity;

import java.util.UUID;

public record BaseOrganization(UUID id, String name) {}
