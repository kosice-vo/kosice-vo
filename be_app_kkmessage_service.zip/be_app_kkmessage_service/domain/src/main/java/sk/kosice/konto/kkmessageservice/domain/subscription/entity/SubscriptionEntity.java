package sk.kosice.konto.kkmessageservice.domain.subscription.entity;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.listing.PaginatedResultItem;

@Value.Immutable
public interface SubscriptionEntity extends BaseSubscriptionEntity, PaginatedResultItem {

  UUID recipientKid();

  BaseTopic topic();

  BaseOrganization organization();
}
