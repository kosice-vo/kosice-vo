package sk.kosice.konto.kkmessageservice.domain.subscription.entity;

import java.util.UUID;

public record BaseTopic(UUID id, String name, String description) {}
