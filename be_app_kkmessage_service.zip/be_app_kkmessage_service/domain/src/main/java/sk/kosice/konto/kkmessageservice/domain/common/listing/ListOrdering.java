package sk.kosice.konto.kkmessageservice.domain.common.listing;

import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.listing.common.ListingAttribute;

@Value.Immutable
public interface ListOrdering<T extends ListingAttribute> {

  @Value.Parameter
  T attribute();

  @Value.Parameter
  boolean ascending();
}
