package sk.kosice.konto.kkmessageservice.domain.topic.command;

import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.marker.AuditableCommand;

@Value.Immutable
public interface CreateTopicCommand extends BaseTopicCommand, AuditableCommand {}
