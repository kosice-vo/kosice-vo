package sk.kosice.konto.kkmessageservice.domain.message.query;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.marker.Query;

@Value.Immutable
public interface FindMessageByIdAndKidQuery extends Query {

  UUID id();

  UUID recipientKid();
}
