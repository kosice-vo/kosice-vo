package sk.kosice.konto.kkmessageservice.domain.common.port;

import sk.kosice.konto.kkmessageservice.domain.common.marker.Query;

public interface UseCaseQuery<Q extends Query, O> {

  O execute(Q query);
}
