package sk.kosice.konto.kkmessageservice.domain.organization.entity;

import java.util.Optional;
import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.listing.PaginatedResultItem;
import sk.kosice.konto.kkmessageservice.domain.common.marker.DomainEntity;

@Value.Immutable
public interface OrganizationEntity extends DomainEntity, PaginatedResultItem {

  UUID id();

  boolean isCityDistrict();

  String name();

  Optional<String> description();
}
