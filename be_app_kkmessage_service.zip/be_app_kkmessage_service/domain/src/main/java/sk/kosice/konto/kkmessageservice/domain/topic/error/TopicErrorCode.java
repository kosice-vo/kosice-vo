package sk.kosice.konto.kkmessageservice.domain.topic.error;

import static sk.kosice.konto.kkmessageservice.domain.common.error.ErrorCodeType.NOT_FOUND;

import sk.kosice.konto.kkmessageservice.domain.common.error.ErrorCode;
import sk.kosice.konto.kkmessageservice.domain.common.error.ErrorCodeType;

public enum TopicErrorCode implements ErrorCode {
  TOPIC_DOES_NOT_EXIST(NOT_FOUND, "Topic with ID '%s' does not exist.");

  private final ErrorCodeType type;
  private final String template;

  TopicErrorCode(ErrorCodeType type, String template) {
    this.type = type;
    this.template = template;
  }

  @Override
  public String template() {
    return this.template;
  }

  @Override
  public ErrorCodeType type() {
    return this.type;
  }
}
