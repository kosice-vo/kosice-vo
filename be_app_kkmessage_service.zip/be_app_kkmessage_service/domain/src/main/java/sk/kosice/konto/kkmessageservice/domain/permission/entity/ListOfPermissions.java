package sk.kosice.konto.kkmessageservice.domain.permission.entity;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import sk.kosice.konto.kkmessageservice.domain.common.enumeration.Permission;
import sk.kosice.konto.kkmessageservice.domain.organization.entity.OrganizationEntity;

public record ListOfPermissions(UUID userId, Map<OrganizationEntity, Set<Permission>> items) {}
