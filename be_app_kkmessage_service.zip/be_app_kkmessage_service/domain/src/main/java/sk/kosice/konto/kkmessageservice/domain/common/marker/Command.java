package sk.kosice.konto.kkmessageservice.domain.common.marker;

public interface Command {}
