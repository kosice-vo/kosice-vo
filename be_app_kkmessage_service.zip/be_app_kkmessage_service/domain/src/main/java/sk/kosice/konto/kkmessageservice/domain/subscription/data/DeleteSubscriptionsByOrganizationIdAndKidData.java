package sk.kosice.konto.kkmessageservice.domain.subscription.data;

import cz.jirutka.rsql.parser.ast.Node;
import java.util.Optional;
import java.util.UUID;
import org.immutables.value.Value;

@Value.Immutable
public interface DeleteSubscriptionsByOrganizationIdAndKidData {

  Optional<Node> rsqlQuery();

  UUID recipientKid();
}
