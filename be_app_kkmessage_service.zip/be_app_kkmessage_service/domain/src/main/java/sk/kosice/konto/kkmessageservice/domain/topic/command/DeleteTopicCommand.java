package sk.kosice.konto.kkmessageservice.domain.topic.command;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.marker.AuditableCommand;

@Value.Immutable
public interface DeleteTopicCommand extends AuditableCommand {

  UUID organizationId();

  UUID id();
}
