package sk.kosice.konto.kkmessageservice.domain.common.port;

public interface UseCaseVoidVoid {

  void execute();
}
