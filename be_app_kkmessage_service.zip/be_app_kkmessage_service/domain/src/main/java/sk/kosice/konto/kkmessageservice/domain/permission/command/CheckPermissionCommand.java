package sk.kosice.konto.kkmessageservice.domain.permission.command;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.enumeration.Permission;
import sk.kosice.konto.kkmessageservice.domain.common.marker.Command;

@Value.Immutable
public interface CheckPermissionCommand extends Command {

  String actorId();

  Permission permissionToCheck();

  UUID actionGroupId();
}
