package sk.kosice.konto.kkmessageservice.domain.message.entity;

import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.listing.PaginatedResult;

@Value.Immutable
public interface ListOfMessages extends PaginatedResult<BaseMessageEntity> {}
