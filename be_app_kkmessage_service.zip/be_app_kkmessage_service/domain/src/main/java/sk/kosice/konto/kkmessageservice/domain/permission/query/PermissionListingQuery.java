package sk.kosice.konto.kkmessageservice.domain.permission.query;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.marker.Query;

@Value.Immutable
public interface PermissionListingQuery extends Query {

  UUID userId();
}
