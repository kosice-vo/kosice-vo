package sk.kosice.konto.kkmessageservice.domain.common.listing;

public interface PaginatedResultItem {}
