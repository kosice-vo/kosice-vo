package sk.kosice.konto.kkmessageservice.domain.common.port;

import sk.kosice.konto.kkmessageservice.domain.common.marker.Command;

public interface UseCaseCommand<C extends Command, O> {

  O execute(C command);
}
