package sk.kosice.konto.kkmessageservice.domain.topic.command;

import java.util.UUID;
import org.immutables.value.Value;

@Value.Immutable
public interface BaseTopicCommand {

  String name();

  String description();

  UUID organizationId();
}
