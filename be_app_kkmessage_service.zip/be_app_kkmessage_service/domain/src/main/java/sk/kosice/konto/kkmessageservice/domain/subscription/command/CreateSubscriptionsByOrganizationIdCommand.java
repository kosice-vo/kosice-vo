package sk.kosice.konto.kkmessageservice.domain.subscription.command;

import java.util.List;
import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.marker.Command;

@Value.Immutable
public interface CreateSubscriptionsByOrganizationIdCommand extends Command {

  UUID recipientKid();

  List<UUID> organizationIds();
}
