package sk.kosice.konto.kkmessageservice.domain.message.query;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.marker.AuditableQuery;

@Value.Immutable
public interface FindMessageByIdAndOrganizationIdQuery extends AuditableQuery {

  UUID id();

  UUID organizationId();
}
