package sk.kosice.konto.kkmessageservice.domain.subscription.query;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.listing.ListingQuery;
import sk.kosice.konto.kkmessageservice.domain.common.listing.SubscriptionListingAttribute;
import sk.kosice.konto.kkmessageservice.domain.common.marker.Query;

@Value.Immutable
public interface SubscriptionListingQuery
    extends Query, ListingQuery<SubscriptionListingAttribute> {
  UUID recipientKid();
}
