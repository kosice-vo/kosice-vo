package sk.kosice.konto.kkmessageservice.domain.topic.data;

import java.util.UUID;
import org.immutables.value.Value;

@Value.Immutable
public interface DeleteTopicData {

  UUID organizationId();

  UUID id();
}
