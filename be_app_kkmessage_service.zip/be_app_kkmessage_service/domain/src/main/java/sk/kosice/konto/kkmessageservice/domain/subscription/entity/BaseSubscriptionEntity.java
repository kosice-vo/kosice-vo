package sk.kosice.konto.kkmessageservice.domain.subscription.entity;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.marker.DomainEntity;

@Value.Immutable
public interface BaseSubscriptionEntity extends DomainEntity {

  UUID id();

  Boolean isEmailEnabled();
}
