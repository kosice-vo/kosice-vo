package sk.kosice.konto.kkmessageservice.domain.subscription.entity;

import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.listing.PaginatedResult;

@Value.Immutable
public interface ListOfSubscriptions extends PaginatedResult<SubscriptionEntity> {}
