package sk.kosice.konto.kkmessageservice.domain.message.query;

import java.util.Optional;
import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.listing.ListingQuery;
import sk.kosice.konto.kkmessageservice.domain.common.listing.MessageListingAttribute;
import sk.kosice.konto.kkmessageservice.domain.common.marker.AuditableQuery;

@Value.Immutable
public interface MessageListingQuery extends AuditableQuery, ListingQuery<MessageListingAttribute> {

  Optional<UUID> recipientKid();

  Optional<UUID> organizationId();
}
