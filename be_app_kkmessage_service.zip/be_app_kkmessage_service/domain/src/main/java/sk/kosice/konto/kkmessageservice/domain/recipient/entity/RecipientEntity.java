package sk.kosice.konto.kkmessageservice.domain.recipient.entity;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.marker.DomainEntity;

@Value.Immutable
public interface RecipientEntity extends DomainEntity {

  UUID kid();

  String email();
}
