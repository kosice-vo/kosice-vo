package sk.kosice.konto.kkmessageservice.domain.organization.query;

import java.util.Optional;
import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.listing.ListingQuery;
import sk.kosice.konto.kkmessageservice.domain.common.listing.OrganizationListingAttribute;
import sk.kosice.konto.kkmessageservice.domain.common.marker.AuditableQuery;

@Value.Immutable
public interface OrganizationListingQuery
    extends AuditableQuery, ListingQuery<OrganizationListingAttribute> {
  Optional<UUID> rootOrganizationId();
}
