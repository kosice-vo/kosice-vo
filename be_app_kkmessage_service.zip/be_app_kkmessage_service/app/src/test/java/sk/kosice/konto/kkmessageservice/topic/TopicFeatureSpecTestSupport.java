package sk.kosice.konto.kkmessageservice.topic;

public interface TopicFeatureSpecTestSupport {}
