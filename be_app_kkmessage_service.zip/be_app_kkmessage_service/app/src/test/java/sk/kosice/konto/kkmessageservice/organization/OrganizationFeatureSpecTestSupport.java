package sk.kosice.konto.kkmessageservice.organization;

public interface OrganizationFeatureSpecTestSupport {}
