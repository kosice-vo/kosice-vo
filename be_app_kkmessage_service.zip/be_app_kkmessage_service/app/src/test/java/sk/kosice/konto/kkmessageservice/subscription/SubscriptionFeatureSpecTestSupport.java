package sk.kosice.konto.kkmessageservice.subscription;

public interface SubscriptionFeatureSpecTestSupport {}
