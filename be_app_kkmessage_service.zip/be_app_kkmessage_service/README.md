# kkmessage micro-service

# Pre Build setup steps
It's necessary to set up DB.
```bash
docker-compose -f docker-compose-db.yml up -d
```

# Build
```shell script
bin/build.sh  # Unix-like
bin\build.bat # Windows
```
# Run
```shell script
bin/with_env_vars.sh bootRun  # Unix-like
bin\with_env_vars.bat bootRun # Windows
```
# Swagger UI
http://localhost:8080/internal/swagger-ui/index.html
