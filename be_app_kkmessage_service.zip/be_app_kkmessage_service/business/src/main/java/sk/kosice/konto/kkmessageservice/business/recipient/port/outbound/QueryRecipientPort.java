package sk.kosice.konto.kkmessageservice.business.recipient.port.outbound;

import java.util.UUID;
import sk.kosice.konto.kkmessageservice.domain.common.error.BusinessException;
import sk.kosice.konto.kkmessageservice.domain.recipient.entity.RecipientEntity;

public interface QueryRecipientPort {

  RecipientEntity findOne(UUID kid) throws BusinessException;
}
