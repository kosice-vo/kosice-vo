package sk.kosice.konto.kkmessageservice.business.topic.port.inbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseVoidCommand;
import sk.kosice.konto.kkmessageservice.domain.topic.command.DeleteTopicCommand;

public interface DeleteTopicUseCase extends UseCaseVoidCommand<DeleteTopicCommand> {}
