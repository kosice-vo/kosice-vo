package sk.kosice.konto.kkmessageservice.business.topic.port.inbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseCommand;
import sk.kosice.konto.kkmessageservice.domain.topic.command.CreateTopicCommand;
import sk.kosice.konto.kkmessageservice.domain.topic.entity.TopicEntity;

public interface CreateTopicUseCase extends UseCaseCommand<CreateTopicCommand, TopicEntity> {}
