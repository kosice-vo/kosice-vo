package sk.kosice.konto.kkmessageservice.business.organization.port.outbound;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import sk.kosice.konto.kkmessageservice.domain.common.error.BusinessException;
import sk.kosice.konto.kkmessageservice.domain.organization.entity.OrganizationEntity;

public interface QueryOrganizationPort {

  List<OrganizationEntity> list(Optional<UUID> rootGroupId) throws BusinessException;

  OrganizationEntity findOne(UUID organizationId) throws BusinessException;

  List<OrganizationEntity> getUserGroups(String userId);

  List<UUID> getUserGroupIds(String userId);
}
