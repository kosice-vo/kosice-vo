package sk.kosice.konto.kkmessageservice.business.permission.port.inbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseQuery;
import sk.kosice.konto.kkmessageservice.domain.permission.entity.ListOfPermissions;
import sk.kosice.konto.kkmessageservice.domain.permission.query.PermissionListingQuery;

public interface ListPermissionUseCase
    extends UseCaseQuery<PermissionListingQuery, ListOfPermissions> {}
