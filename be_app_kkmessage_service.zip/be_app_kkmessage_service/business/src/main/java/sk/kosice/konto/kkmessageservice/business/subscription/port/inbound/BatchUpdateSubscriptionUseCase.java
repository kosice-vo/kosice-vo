package sk.kosice.konto.kkmessageservice.business.subscription.port.inbound;

import java.util.List;
import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseCommand;
import sk.kosice.konto.kkmessageservice.domain.subscription.command.BatchUpdateSubscriptionCommand;
import sk.kosice.konto.kkmessageservice.domain.subscription.entity.SubscriptionEntity;

public interface BatchUpdateSubscriptionUseCase
    extends UseCaseCommand<BatchUpdateSubscriptionCommand, List<SubscriptionEntity>> {}
