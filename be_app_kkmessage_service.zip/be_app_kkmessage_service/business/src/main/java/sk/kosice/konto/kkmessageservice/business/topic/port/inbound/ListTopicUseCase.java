package sk.kosice.konto.kkmessageservice.business.topic.port.inbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseQuery;
import sk.kosice.konto.kkmessageservice.domain.topic.entity.ListOfTopics;
import sk.kosice.konto.kkmessageservice.domain.topic.query.TopicListingQuery;

public interface ListTopicUseCase extends UseCaseQuery<TopicListingQuery, ListOfTopics> {}
