package sk.kosice.konto.kkmessageservice.business.message.port.inbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseCommand;
import sk.kosice.konto.kkmessageservice.domain.message.command.CreateMessageCommand;
import sk.kosice.konto.kkmessageservice.domain.message.entity.MessageEntity;

public interface CreateMessageUseCase extends UseCaseCommand<CreateMessageCommand, MessageEntity> {}
