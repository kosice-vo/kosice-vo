package sk.kosice.konto.kkmessageservice.business.recipient.port.outbound;

import sk.kosice.konto.kkmessageservice.domain.common.error.BusinessException;
import sk.kosice.konto.kkmessageservice.domain.recipient.entity.RecipientEntity;

public interface PersistRecipientPort {

  void insert(RecipientEntity data) throws BusinessException;
}
