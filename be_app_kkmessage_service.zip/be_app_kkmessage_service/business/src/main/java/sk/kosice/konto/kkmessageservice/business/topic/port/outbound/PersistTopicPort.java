package sk.kosice.konto.kkmessageservice.business.topic.port.outbound;

import sk.kosice.konto.kkmessageservice.domain.common.error.BusinessException;
import sk.kosice.konto.kkmessageservice.domain.topic.data.DeleteTopicData;
import sk.kosice.konto.kkmessageservice.domain.topic.entity.TopicEntity;

public interface PersistTopicPort {

  void insert(TopicEntity data) throws BusinessException;

  void update(TopicEntity data) throws BusinessException;

  void delete(DeleteTopicData data) throws BusinessException;
}
