package sk.kosice.konto.kkmessageservice.business.subscription.port.inbound;

import java.util.List;
import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseCommand;
import sk.kosice.konto.kkmessageservice.domain.subscription.command.CreateSubscriptionsByOrganizationIdCommand;
import sk.kosice.konto.kkmessageservice.domain.subscription.entity.SubscriptionEntity;

public interface CreateSubscriptionsByOrganizationIdUseCase
    extends UseCaseCommand<CreateSubscriptionsByOrganizationIdCommand, List<SubscriptionEntity>> {}
