package sk.kosice.konto.kkmessageservice.business.subscription.port.outbound;

import java.util.List;
import sk.kosice.konto.kkmessageservice.domain.subscription.entity.ListOfSubscriptions;
import sk.kosice.konto.kkmessageservice.domain.subscription.entity.SubscriptionEntity;
import sk.kosice.konto.kkmessageservice.domain.subscription.query.FindSubscribedOrganizationsByKidQuery;
import sk.kosice.konto.kkmessageservice.domain.subscription.query.FindSubscriptionByIdQuery;
import sk.kosice.konto.kkmessageservice.domain.subscription.query.SubscriptionListingQuery;

public interface QuerySubscriptionPort {

  ListOfSubscriptions list(SubscriptionListingQuery query);

  List<SubscriptionEntity> listWithoutPaging(SubscriptionListingQuery query);

  SubscriptionEntity findOne(FindSubscriptionByIdQuery query);

  List<SubscriptionEntity> listUniqueForKid(FindSubscribedOrganizationsByKidQuery query);
}
