package sk.kosice.konto.kkmessageservice.business.organization.port.inbound;

import java.util.List;
import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseQuery;
import sk.kosice.konto.kkmessageservice.domain.organization.entity.OrganizationEntity;
import sk.kosice.konto.kkmessageservice.domain.organization.query.OrganizationListingQuery;

public interface ListOrganizationUseCase
    extends UseCaseQuery<OrganizationListingQuery, List<OrganizationEntity>> {}
