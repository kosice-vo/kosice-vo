package sk.kosice.konto.kkmessageservice.business.message.port.outbound;

import sk.kosice.konto.kkmessageservice.domain.common.error.BusinessException;
import sk.kosice.konto.kkmessageservice.domain.message.entity.MessageEntity;

public interface PersistMessagePort {

  void insert(MessageEntity data) throws BusinessException;
}
