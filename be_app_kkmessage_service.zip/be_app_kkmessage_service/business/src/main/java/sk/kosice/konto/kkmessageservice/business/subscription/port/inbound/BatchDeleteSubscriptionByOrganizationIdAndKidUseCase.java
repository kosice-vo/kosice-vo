package sk.kosice.konto.kkmessageservice.business.subscription.port.inbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseVoidCommand;
import sk.kosice.konto.kkmessageservice.domain.subscription.command.DeleteSubscriptionsByOrganizationIdAndKidCommand;

public interface BatchDeleteSubscriptionByOrganizationIdAndKidUseCase
    extends UseCaseVoidCommand<DeleteSubscriptionsByOrganizationIdAndKidCommand> {}
