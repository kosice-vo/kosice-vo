package sk.kosice.konto.kkmessageservice.business.subscription.port.inbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseQuery;
import sk.kosice.konto.kkmessageservice.domain.subscription.entity.ListOfSubscriptions;
import sk.kosice.konto.kkmessageservice.domain.subscription.query.SubscriptionListingQuery;

public interface ListSubscriptionUseCase
    extends UseCaseQuery<SubscriptionListingQuery, ListOfSubscriptions> {}
