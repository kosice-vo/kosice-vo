package sk.kosice.konto.kkmessageservice.business.message.port.outbound;

import sk.kosice.konto.kkmessageservice.domain.common.error.BusinessException;
import sk.kosice.konto.kkmessageservice.domain.message.entity.ListOfMessages;
import sk.kosice.konto.kkmessageservice.domain.message.entity.MessageEntity;
import sk.kosice.konto.kkmessageservice.domain.message.query.FindMessageByIdAndKidQuery;
import sk.kosice.konto.kkmessageservice.domain.message.query.FindMessageByIdAndOrganizationIdQuery;
import sk.kosice.konto.kkmessageservice.domain.message.query.FindMessageByIdQuery;
import sk.kosice.konto.kkmessageservice.domain.message.query.MessageListingQuery;

public interface QueryMessagePort {

  @Deprecated
  MessageEntity findOne(FindMessageByIdQuery query) throws BusinessException;

  MessageEntity findOne(FindMessageByIdAndKidQuery query) throws BusinessException;

  MessageEntity findOne(FindMessageByIdAndOrganizationIdQuery query) throws BusinessException;

  ListOfMessages list(MessageListingQuery query) throws BusinessException;
}
