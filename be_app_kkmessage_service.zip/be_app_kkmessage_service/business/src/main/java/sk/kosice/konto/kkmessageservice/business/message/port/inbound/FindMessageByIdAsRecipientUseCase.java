package sk.kosice.konto.kkmessageservice.business.message.port.inbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseQuery;
import sk.kosice.konto.kkmessageservice.domain.message.entity.MessageEntity;
import sk.kosice.konto.kkmessageservice.domain.message.query.FindMessageByIdAndKidQuery;

public interface FindMessageByIdAsRecipientUseCase
    extends UseCaseQuery<FindMessageByIdAndKidQuery, MessageEntity> {}
