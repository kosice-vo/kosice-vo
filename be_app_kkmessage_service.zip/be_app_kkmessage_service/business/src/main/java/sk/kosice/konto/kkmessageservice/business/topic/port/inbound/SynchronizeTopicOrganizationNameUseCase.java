package sk.kosice.konto.kkmessageservice.business.topic.port.inbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseVoidVoid;

public interface SynchronizeTopicOrganizationNameUseCase extends UseCaseVoidVoid {}
