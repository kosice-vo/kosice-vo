package sk.kosice.konto.kkmessageservice.business.topic.port.outbound;

import java.util.List;
import java.util.UUID;
import sk.kosice.konto.kkmessageservice.domain.common.error.BusinessException;
import sk.kosice.konto.kkmessageservice.domain.topic.entity.ListOfTopics;
import sk.kosice.konto.kkmessageservice.domain.topic.entity.TopicEntity;
import sk.kosice.konto.kkmessageservice.domain.topic.query.FindTopicByIdQuery;
import sk.kosice.konto.kkmessageservice.domain.topic.query.TopicListingQuery;

public interface QueryTopicPort {

  TopicEntity findOne(FindTopicByIdQuery query) throws BusinessException;

  ListOfTopics list(TopicListingQuery query) throws BusinessException;

  List<TopicEntity> listByOrganizationId(UUID organizationId);
}
