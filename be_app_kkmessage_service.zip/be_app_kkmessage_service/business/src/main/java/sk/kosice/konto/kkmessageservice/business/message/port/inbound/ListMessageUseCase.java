package sk.kosice.konto.kkmessageservice.business.message.port.inbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseQuery;
import sk.kosice.konto.kkmessageservice.domain.message.entity.ListOfMessages;
import sk.kosice.konto.kkmessageservice.domain.message.query.MessageListingQuery;

public interface ListMessageUseCase extends UseCaseQuery<MessageListingQuery, ListOfMessages> {}
