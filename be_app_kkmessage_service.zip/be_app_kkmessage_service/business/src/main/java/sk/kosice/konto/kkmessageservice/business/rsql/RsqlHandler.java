package sk.kosice.konto.kkmessageservice.business.rsql;

import cz.jirutka.rsql.parser.ast.Node;

public interface RsqlHandler {

  Node parse(String query);
}
