package sk.kosice.konto.kkmessageservice.business.topic.port.inbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseCommand;
import sk.kosice.konto.kkmessageservice.domain.topic.command.UpdateTopicCommand;
import sk.kosice.konto.kkmessageservice.domain.topic.entity.TopicEntity;

public interface UpdateTopicUseCase extends UseCaseCommand<UpdateTopicCommand, TopicEntity> {}
