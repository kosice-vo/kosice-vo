package sk.kosice.konto.kkmessageservice.business.topic.port.inbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseQuery;
import sk.kosice.konto.kkmessageservice.domain.topic.entity.TopicEntity;
import sk.kosice.konto.kkmessageservice.domain.topic.query.FindTopicByIdQuery;

public interface FindTopicByIdUseCase extends UseCaseQuery<FindTopicByIdQuery, TopicEntity> {}
