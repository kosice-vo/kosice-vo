package sk.kosice.konto.kkmessageservice.business.permission.port.outbound;

import sk.kosice.konto.kkmessageservice.domain.common.port.UseCaseCommand;
import sk.kosice.konto.kkmessageservice.domain.permission.command.CheckPermissionCommand;

public interface CheckPermissionsUseCase extends UseCaseCommand<CheckPermissionCommand, Boolean> {}
