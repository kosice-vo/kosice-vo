CREATE USER kkmessage_admin WITH PASSWORD 'password';

GRANT USAGE ON SCHEMA kk_message_data TO kkmessage_admin;

GRANT CREATE ON SCHEMA kk_message_data TO kkmessage_admin;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA kk_message_data TO kkmessage_admin;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA kk_message_data TO kkmessage_admin;
GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN SCHEMA kk_message_data TO kkmessage_admin;
