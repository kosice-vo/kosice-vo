class DbSettings {

  String jdbcUrl
  String liquibaseUserName
  String liquibasePassword
  String username
  String password
  String dbSchema
  String notification_username

  DbSettings(String jdbcUrl, String liquibaseUserName, String liquibasePassword, String username, String password, String dbSchema, String notification_username) {
    this.jdbcUrl = jdbcUrl
    this.liquibaseUserName = liquibaseUserName
    this.liquibasePassword = liquibasePassword
    this.username = username
    this.password = password
    this.dbSchema = dbSchema
    this.notification_username = notification_username
  }

  String getJdbcUrl() {
    return jdbcUrl
  }

  String getLiquibaseUserName() {
    return liquibaseUserName
  }

  String getLiquibasePassword() {
    return liquibasePassword
  }

  String getUsername() {
    return username
  }

  String getPassword() {
    return password
  }

  String getDbSchema() {
    return dbSchema
  }

  String getNotificationUsername() {
    return notification_username
  }
}
