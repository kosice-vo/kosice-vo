# Moje Kosice

Personal zone of the resident of the city of Košice

## Table of Contents

- [Contributing](#contribution)
- [Build](#build-the-application)

## Contributing

### Prerequisities

- npm
- node.js

### Installation

Clone the repository

```
git clone git@github.com:slovakia-kosice/web_app_konto_kosice_sk.git
```

Setup Local environment

```bash
export NPM_TOKEN=${token} # Use Your personal GitHub token
```

Install dependencies

```
cd web_app_konto_kosice_sk
# export NPM_TOKEN=${token} # Use Your perosnal GitHub token
npm install
```

Setup enviroment variables in .env or .env-local file

```
NEXTAUTH_SECRET=8FD68ABF1183DDAC5826C68891698

AZURE_AD_CLIENT_ID=<uuid>
AZURE_AD_CLIENT_SECRET=<string>
AZURE_AD_TENANT_ID=<uuid>
AZURE_AD_AUTH_URL=<url>
AZURE_AD_TOKEN_URL=<url>
AZURE_AD_ISSUER=<url>
AZURE_AD_SCOPE=<string>

API_BASE_URL=<url>
API_HEADER_X_APP_PLATFORM=web
API_HEADER_X_APP_ID=<uuid>
API_HEADER_X_DEVICE_ID=<uuid>
```

If production setup use proxy, then set NEXTAUTH_URL with domain for rendering URLs.
```
NEXTAUTH_URL=<url>
```

Run local dev server

```
npm run dev
```

## Build the application

Run build command

```
npm run build
```

Final build of the application is contained inside the `.next` folder.
