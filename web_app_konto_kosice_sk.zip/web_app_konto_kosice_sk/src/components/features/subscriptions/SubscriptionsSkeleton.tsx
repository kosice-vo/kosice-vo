import React from 'react';
import { Loader } from '@/lib/idsk';

const SubscriptionsSkeleton: React.FC = () => (
  <div className="px-6 py-24 flex items-center justify-center w-full bg-white border rounded-xl border-neutral-300">
    <Loader />
  </div>
);

export default SubscriptionsSkeleton;
