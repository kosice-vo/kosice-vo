export { default as InformationDialog } from './InformationDialog';
