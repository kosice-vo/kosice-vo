'use client';

import React from 'react';
import { EnvironmentContext } from '@/context';

interface EnvironmentProviderProps {
  environment: any;
  children: React.ReactNode;
}

const EnvironmentProvider: React.FC<EnvironmentProviderProps> = ({ environment, children }) => (
  <EnvironmentContext.Provider value={environment}>{children}</EnvironmentContext.Provider>
);

export default EnvironmentProvider;
