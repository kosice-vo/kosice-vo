export { validateMessageDetail } from './message-detail';
