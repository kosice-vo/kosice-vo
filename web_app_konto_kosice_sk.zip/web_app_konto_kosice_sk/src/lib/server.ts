import fs from 'fs';
import path from 'path';

export const getBuildInfo = () => {
  const filePath = path.join(process.cwd(), 'public', 'version.json');

  if (fs.existsSync(filePath)) {
    const data = fs.readFileSync(filePath, 'utf8');
    const buildInfo = JSON.parse(data);

    return buildInfo;
  }
};
