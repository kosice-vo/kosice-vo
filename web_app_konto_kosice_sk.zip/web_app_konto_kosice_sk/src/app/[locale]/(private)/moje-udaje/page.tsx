'use client';

import React from 'react';
import { useTranslations } from 'next-intl';
import axios from 'axios';
import { useSession } from 'next-auth/react';
import { useQuery } from '@tanstack/react-query';
import { Loader } from '@/lib/idsk';
import { Addresses, Card, Contact, Error, FamilyAndProperty, Heading, PersonalData } from '@/components';
import { Profile, RequestError, unwrap } from '@/utils';

const MyInfo: React.FC = () => {
  const t = useTranslations('my_data');

  const session = useSession();

  const { status, data, error } = useQuery<Profile, RequestError>({
    queryFn: () => unwrap<Profile>(axios.get(`/api/v1/kk/profiles/${session.data?.user.id}`)),
    queryKey: ['profile']
  });

  const preferredContacts = {
    email: data?.identity.emailPreferred || '',
    phone: data?.identity.phonePreferred || ''
  };

  return (
    <>
      <Heading>
        <h2>{t('my_information')}</h2>
      </Heading>

      <div className="flex flex-col gap-7">
        {!!error && <Error err={error} asBanner />}
        <PersonalData />
        {!error && (
          <>
            <Addresses status={status} data={data?.addresses || []} />
            <Card title={t('contacts')}>
              {status === 'pending' && (
                <div className="px-6 py-12 flex items-center justify-center w-full">
                  <Loader />
                </div>
              )}
              {status === 'success' && (
                <div className="flex flex-col gap-14">
                  <Contact data={data?.identity.emails || []} type="email" preferred={preferredContacts} />
                  <Contact data={data?.identity.phones || []} type="phone" preferred={preferredContacts} />
                </div>
              )}
            </Card>
          </>
        )}
        <FamilyAndProperty session={session} />
      </div>
    </>
  );
};

export default MyInfo;
