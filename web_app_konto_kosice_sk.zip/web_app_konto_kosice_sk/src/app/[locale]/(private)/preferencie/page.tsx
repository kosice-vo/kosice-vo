import React from 'react';
import { useTranslations } from 'next-intl';
import { Heading, SubscriptionsList } from '@/components';

const ProfilePage = () => {
  const t = useTranslations('profile_page');
  return (
    <>
      <Heading>
        <h2>{t('title')}</h2>
        <p className="idsk-text-body">{t('description')}</p>
      </Heading>

      <SubscriptionsList />
    </>
  );
};

export default ProfilePage;
