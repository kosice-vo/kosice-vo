'use client';

import axios from 'axios';
import React, { useMemo } from 'react';
import { useTranslations } from 'next-intl';
import { useSession } from 'next-auth/react';
import { useQuery } from '@tanstack/react-query';
import WorkingMan from '@/assets/working_man.svg';
import { Card, Copy, Error, Proceedings, Heading } from '@/components';
import { Proceeding, Proceedings as ProceedingsType, RequestError, unwrap } from '@/utils';
import { useBreakpoint } from '@/hooks';

const Payments: React.FC = () => {
  const t = useTranslations('taxes');
  const session = useSession();
  const kid = session.data?.user?.id;

  const { Breakpoints, match } = useBreakpoint();

  const view = match(Breakpoints.tb1) ? 'table' : 'list';

  const { status, error, data } = useQuery<ProceedingsType, RequestError>({
    queryKey: ['proceedings'],
    queryFn: () => unwrap(axios.get(`/api/v1/kk/profiles/${kid}/proceeding?start=0&limit=100`))
  });

  const categories = useMemo(() => {
    const taxes: Proceeding[] = [];
    const payments: Proceeding[] = [];

    if (status === 'success' && data) {
      data.proceedings.forEach((proceeding) => {
        if (proceeding.subcategories.includes('Poplatok za odpad')) {
          payments.push(proceeding);
        } else {
          taxes.push(proceeding);
        }
      });
    }

    return {
      taxes,
      payments
    };
  }, [data, status]);

  return (
    <>
      <Heading>
        <h2>{t('taxes_and_payments')}</h2>
      </Heading>

      <div className="flex flex-col gap-8">
        {!!error && <Error err={error} asBanner />}

        <Card title={t('taxes')}>
          <Proceedings status={status} type="tax" items={categories.taxes} view={view} />
        </Card>

        <Card title={t('waste_fees')}>
          <Proceedings status={status} type="payment" items={categories.payments} view={view} />
        </Card>

        <div className="border border-blue-300 bg-blue-100 rounded-md p-7 flex flex-col tb1:flex-row gap-7 items-center idsk-text-body">
          <WorkingMan className="w-24 tb1:w-32 flex-shrink-0" />
          <div className="flex flex-col gap-3">
            <p>
              {t.rich('administrator', {
                name: () => <b>Referát daní a poplatkov</b>
              })}
            </p>
            <div className="flex gap-2 tb2:gap-7 flex-wrap">
              <div>
                <Copy value="+421 55 6419 111">
                  {t.rich('phone_number', {
                    tel: () => <b>+421 55 6419 111</b>
                  })}
                </Copy>
              </div>
              <div className="w-[1px] bg-blue-300 hidden tb2:block" />
              <div>
                <Copy value="dane@kosice.sk">
                  {t.rich('email', {
                    email: () => <b>dane@kosice.sk</b>
                  })}
                </Copy>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Payments;
