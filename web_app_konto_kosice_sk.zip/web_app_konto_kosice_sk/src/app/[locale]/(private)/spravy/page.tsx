'use client';

import React, { useRef, useState } from 'react';
import { useTranslations } from 'next-intl';
import { useRouter, useSearchParams } from 'next/navigation';
import { SearchBar } from '@/lib/idsk';
import { Pagination, MessageList, Heading } from '@/components';

const PAGE_SIZE = 5;

const Mailbox: React.FC = () => {
  const [totalCount, setTotalCount] = useState<number>(0);
  const t = useTranslations('messages');
  const router = useRouter();
  const params = useSearchParams();

  const ref = useRef<HTMLInputElement>(null);

  const page = Number(params.get('page') || 1);
  const search = params.get('search') || '';

  const onPageChange = (newPage: number) => {
    const newParams = new URLSearchParams(params.toString());
    newParams.set('page', newPage.toString());
    router.push(`/spravy?${newParams.toString()}`);
  };

  const onSearch = () => {
    const newParams = new URLSearchParams(params.toString());
    newParams.set('search', ref.current?.value || '');
    newParams.set('page', '1');
    router.push(`/spravy?${newParams.toString()}`);
  };

  const onClearSearch = () => {
    const newParams = new URLSearchParams(params.toString());
    newParams.delete('search');
    newParams.set('page', '1');
    router.push(`/spravy?${newParams.toString()}`);
  };

  return (
    <>
      <Heading className="flex justify-between tb2:flex-row flex-col gap-4">
        <h2>{t('mailbox')}</h2>
        <SearchBar
          ref={ref}
          searchbarSize="medium"
          showCancelButton={!!search}
          buttonOnClick={onSearch}
          onCancel={onClearSearch}
          fullWidth
        />
      </Heading>

      <MessageList page={page} pageSize={PAGE_SIZE} search={search} onLoad={(data) => setTotalCount(data.totalCount)} />
      {totalCount > PAGE_SIZE && (
        <div className="mt-7">
          <Pagination
            page={page}
            pageSize={PAGE_SIZE}
            totalCount={totalCount}
            onPageChange={(selected) => onPageChange(selected)}
          />
        </div>
      )}
    </>
  );
};

export default Mailbox;
