'use client';

import React from 'react';
import { Error as ErrorUI, Heading, MessageBackButton } from '@/components';

export default function Error({ error }: { error: Error & { digest?: string } }) {
  return (
    <>
      <Heading>
        <MessageBackButton />
      </Heading>
      <ErrorUI err={JSON.parse(error.message)} />
    </>
  );
}
