import React, { Suspense } from 'react';
import { redirect } from 'next/navigation';
import { Heading, MessageBackButton, MessageDetail, MessageSkeleton } from '@/components';
import { auth } from '@/auth';

const MessageDetailPage: React.FC<{ params: Promise<{ locale: string; id: string }> }> = async (props) => {
  const params = await props.params;
  const { locale, id } = params;
  const session = await auth();

  if (!session) redirect('/uvod');

  return (
    <div>
      <Heading>
        <MessageBackButton />
      </Heading>

      <Suspense fallback={<MessageSkeleton />}>
        <MessageDetail id={id} locale={locale} user={session.user} />
      </Suspense>
    </div>
  );
};
export default MessageDetailPage;
