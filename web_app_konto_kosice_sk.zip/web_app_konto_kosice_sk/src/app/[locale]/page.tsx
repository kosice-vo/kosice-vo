'use client';
import React from 'react';
import { Signpost } from '@slovakia-kosice/idsk-react';
import { useTranslations } from 'next-intl';
import { LinkCard, PersonalData, Section } from '@/components';
import { WithUser } from '@/components/core/with-user';
import MailboxIcon from '@/assets/mailbox-icon.svg';
import TaxesIcon from '@/assets/taxes-icon.svg';
import MyDataIcon from '@/assets/my-data-icon.svg';
import Illustration from '@/assets/home_illustration.svg';

const Dashboard: React.FC = () => {
  const t = useTranslations('homepage');

  return (
    <>
      <div>
        <Illustration />

        <WithUser fallback={<h2 className="mt-11">{t('welcome', { name: '' })}</h2>}>
          {(user) => <h2 className="mt-11">{t('welcome', { name: user.name })}</h2>}
        </WithUser>

        <p className="mt-5 idsk-text-body max-w-3xl">
          {t.rich('info_text', {
            link: (chunks) => (
              <a href="https://konto.kosice.sk/" target="_blank" className="idsk-link-m" rel="noreferrer">
                {chunks}
              </a>
            )
          })}
        </p>
      </div>

      <div className="flex flex-col gap-10 mt-16">
        <div className="grid tb2:grid-cols-2 dm1:grid-cols-3 gap-5">
          <LinkCard
            href="/spravy"
            icon={<MailboxIcon />}
            title={t('link_card_mailbox_title')}
            label={t('link_card_mailbox_button')}
          >
            {t('link_card_mailbox_description')}
          </LinkCard>
          <LinkCard
            href="/dane-a-poplatky"
            icon={<TaxesIcon />}
            title={t('link_card_taxes_title')}
            label={t('link_card_taxes_button')}
          >
            {t('link_card_taxes_description')}
          </LinkCard>
          <LinkCard
            href="/moje-udaje"
            icon={<MyDataIcon />}
            title={t('link_card_mydata_title')}
            label={t('link_card_mydata_button')}
            className="tb2:col-span-2 dm1:col-span-1"
          >
            {t('link_card_mydata_description')}
          </LinkCard>
        </div>

        <PersonalData />

        <Section heading={t('usefull_links')}>
          <div className="grid tb2:grid-cols-2 dm1:grid-cols-3 gap-5">
            <Signpost
              href="https://www.kosice.sk/sk"
              heading={t('signpost_5')}
              layout="vertical"
              target="_blank"
              withoutTargetIcon
            >
              {t('signpost_5_desc')}
            </Signpost>
            <Signpost
              href="https://www.esluzbykosice.sk/"
              heading={t('signpost_6')}
              layout="vertical"
              target="_blank"
              withoutTargetIcon
            >
              {t('signpost_6_desc')}
            </Signpost>
            <Signpost
              href="https://visitkosice.org/en"
              heading={t('signpost_7')}
              layout="vertical"
              target="_blank"
              withoutTargetIcon
            >
              {t('signpost_7_desc')}
            </Signpost>
            <Signpost
              href="https://www.dpmk.sk/"
              heading={t('signpost_8')}
              layout="vertical"
              target="_blank"
              withoutTargetIcon
            >
              {t('signpost_8_desc')}
            </Signpost>
            <Signpost
              href="https://parking.kosice.sk/"
              heading={t('signpost_9')}
              layout="vertical"
              target="_blank"
              withoutTargetIcon
            >
              {t('signpost_9_desc')}
            </Signpost>
          </div>
        </Section>
      </div>
    </>
  );
};
export default Dashboard;
