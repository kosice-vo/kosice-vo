'use client';

import React, { useEffect } from 'react';
import { useEnvironment } from '@/context';
import { signIn } from 'next-auth/react';
import { useLocale } from 'next-intl';
import { redirect, useSearchParams } from 'next/navigation';

const SignInPage: React.FC = () => {
  const { config } = useEnvironment();
  const params = useSearchParams();
  const currentLocale = useLocale();
  const provider = params.get('provider') || 'microsoft-entra-id';
  const locale = params.get('ui_locales') || currentLocale;
  const error = params.get('error');

  useEffect(() => {
    if (error) {
      redirect('/uvod');
    }

    if (config.useCredentials || provider === 'credentials') {
      redirect(`/api/auth/authorize?provider=${provider}&ui_locales=${locale}`);
    }

    signIn(provider, { callbackUrl: '/' }, { ui_locales: locale });
  }, [provider, locale, error]);

  return null;
};

export default SignInPage;
