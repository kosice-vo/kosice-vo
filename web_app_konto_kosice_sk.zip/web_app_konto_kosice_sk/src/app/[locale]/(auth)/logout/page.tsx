'use client';

import React, { useEffect } from 'react';
import { logout } from '@/utils';
import { useEnvironment } from '@/context';

const LogoutPage: React.FC = () => {
  const { config } = useEnvironment();
  useEffect(() => {
    logout(config.logoutUrl);
  }, []);
  return null;
};

export default LogoutPage;
