'use client';

import { redirect } from 'next/navigation';
import React, { useEffect } from 'react';

const ErrorPage: React.FC = () => {
  useEffect(() => redirect('/uvod'), []);
  return null;
};

export default ErrorPage;
