import React from 'react';
import { useTranslations } from 'next-intl';
import { CookieSettings } from '@/components';

const CookiesPage = () => {
  const t = useTranslations('cookies');
  return (
    <div className="max-w-3xl flex flex-col gap-7">
      <h1>{t('cookieSettings')}</h1>
      <p>{t('settingsParagraph1')}</p>
      <p>{t('settingsParagraph2')}</p>
      <CookieSettings />
    </div>
  );
};

export default CookiesPage;
