import React from 'react';
import { useTranslations } from 'next-intl';
import Link from 'next/link';
import { SecondaryButton } from '@/lib/idsk';
import WelcomeIllustration from '@/assets/welcomepage-illustration.svg';

const HomePage: React.FC = () => {
  const t = useTranslations('welcomepage');

  return (
    <div className="flex flex-col tb2:flex-row items-center mt-7 gap-8">
      <div className="flex flex-col gap-6">
        <h1>{t('title')}</h1>
        <p className="text-lg leading-6 tb2:text-2xl tb2:leading-9">
          {t.rich('subtitle', {
            b: (chunks) => <b>{chunks}</b>
          })}
        </p>
        <Link href="/signin?provider=microsoft-entra-id-signup">
          <SecondaryButton className="w-fit" size="large">
            {t('create_account')}
          </SecondaryButton>
        </Link>
        <p className="max-w-96">{t('agreement')}</p>
      </div>

      <WelcomeIllustration className="flex-shrink-0 max-w-[32rem]" />
    </div>
  );
};

export default HomePage;
