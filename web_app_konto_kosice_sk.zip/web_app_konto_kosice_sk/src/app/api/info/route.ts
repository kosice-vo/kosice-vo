import { getBuildInfo } from '@/lib/server';

export const GET = () => {
  const buildInfo = getBuildInfo();

  return new Response(JSON.stringify(buildInfo), {
    status: 200,
    headers: {
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache, no-store, must-revalidate, proxy-revalidate'
    }
  });
};
