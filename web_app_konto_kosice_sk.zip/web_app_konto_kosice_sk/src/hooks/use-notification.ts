'use client';

import { useNotificationsContext } from '@/context';

const useNotifications = () => {
  const { notify } = useNotificationsContext();
  return notify;
};

export default useNotifications;
