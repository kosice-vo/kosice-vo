'use client';

import { useLocale } from 'next-intl';

function useLocalLink() {
  const locale = useLocale();

  return (path: string) => `/${locale}${path}`;
}

export default useLocalLink;
