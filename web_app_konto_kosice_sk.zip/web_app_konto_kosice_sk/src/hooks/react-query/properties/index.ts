export { default as useGetProperties } from './use-get-properties';
