import { createNavigation } from 'next-intl/navigation';
import { defineRouting } from 'next-intl/routing';

export const LOCALES = ['sk', 'en'];
export const DEFAULT_LOCALE = 'sk';

export const routing = defineRouting({ locales: LOCALES, defaultLocale: DEFAULT_LOCALE });

export const { Link, redirect, usePathname, useRouter } = createNavigation(routing);
