export type ContactType = 'email' | 'phone';

export type RGB = {
  r: number;
  g: number;
  b: number;
};
