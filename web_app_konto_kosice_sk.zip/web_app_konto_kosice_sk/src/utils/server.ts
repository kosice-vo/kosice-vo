export const getEnvironment = () => ({
  config: {
    createAccount: process.env.CFG_LINK_CREATE_ACCOUNT || '',
    gaTag: process.env.CFG_GA_TAG || '',
    logoutUrl: process.env.CFG_LOGOUT_URL || '',
    phone: process.env.CFG_PHONE || '',
    email: process.env.CFG_EMAIL || '',
    useCredentials: process.env.AUTH_USE_CREDENTIALS === 'true',
    forceReload: Number(process.env.FORCE_RELOAD) || 0
  },
  link: {
    privacyPolicy: process.env.LINK_PRIVACY_POLICY || '',
    accessibilityStatement: process.env.LINK_ACCESIBILITY_STATEMENT || '',
    idsk: process.env.LINK_IDSK || ''
  }
});
