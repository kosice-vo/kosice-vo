export const labels: Record<string, string[]> = {
  success: ['Uhradené', 'Odoslané na spracovanie', 'Odoslané', 'Doručené'],
  basic: [
    'Doručené s doručenkou',
    'Pripravené na odoslanie',
    'Doručené uložením/vrátením',
    'Čiastočne uhradené',
    'Preplatené'
  ],
  attention: ['Neznámy', 'Doručené uplynula lehota', 'Vrátené'],
  warning: [
    'Nedoručené',
    'Doručovanie s chybou',
    'Odoslané čiastočne/neúplné',
    'Doručené čiastočne/neúplné',
    'Neuhradené'
  ]
};
