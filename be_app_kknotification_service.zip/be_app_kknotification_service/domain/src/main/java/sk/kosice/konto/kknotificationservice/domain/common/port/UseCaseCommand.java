package sk.kosice.konto.kknotificationservice.domain.common.port;

import sk.kosice.konto.kknotificationservice.domain.common.marker.Command;

public interface UseCaseCommand<C extends Command, O> {

  O execute(C command);
}
