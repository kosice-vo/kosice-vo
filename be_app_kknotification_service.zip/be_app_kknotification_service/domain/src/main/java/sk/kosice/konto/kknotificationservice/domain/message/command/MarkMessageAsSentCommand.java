package sk.kosice.konto.kknotificationservice.domain.message.command;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kknotificationservice.domain.common.marker.Command;

@Value.Immutable
public interface MarkMessageAsSentCommand extends Command {

  UUID messageId();
}
