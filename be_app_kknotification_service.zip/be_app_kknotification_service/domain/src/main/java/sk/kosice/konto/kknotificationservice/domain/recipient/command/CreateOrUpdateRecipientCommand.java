package sk.kosice.konto.kknotificationservice.domain.recipient.command;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kknotificationservice.domain.common.marker.AuditableCommand;

@Value.Immutable
public interface CreateOrUpdateRecipientCommand extends AuditableCommand {

  UUID kid();

  String preferredEmail();
}
