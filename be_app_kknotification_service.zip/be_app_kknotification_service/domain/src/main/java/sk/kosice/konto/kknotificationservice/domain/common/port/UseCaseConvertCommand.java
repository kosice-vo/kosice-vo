package sk.kosice.konto.kknotificationservice.domain.common.port;

import sk.kosice.konto.kknotificationservice.domain.common.marker.Command;
import sk.kosice.konto.kknotificationservice.domain.common.marker.DomainEntity;

public interface UseCaseConvertCommand<C extends DomainEntity, O extends Command> {

  O execute(C entity);
}
