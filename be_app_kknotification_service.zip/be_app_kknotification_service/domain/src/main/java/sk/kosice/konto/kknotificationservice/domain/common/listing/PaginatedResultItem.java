package sk.kosice.konto.kknotificationservice.domain.common.listing;

public interface PaginatedResultItem {}
