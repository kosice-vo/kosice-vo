package sk.kosice.konto.kknotificationservice.domain.recipient.entity;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kknotificationservice.domain.common.marker.DomainEntity;

@Value.Immutable
public interface RecipientEntity extends DomainEntity {

  UUID kid();

  String email();
}
