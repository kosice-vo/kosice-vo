package sk.kosice.konto.kknotificationservice.domain.common;

import org.immutables.value.Value;

@Value.Immutable
public abstract class ActorIdentity {

  @Value.Parameter
  public abstract String id();
}
