package sk.kosice.konto.kknotificationservice.domain.email.entity;

import org.immutables.value.Value;

@Value.Immutable
public interface SenderInfo {
  String email();

  String name();
}
