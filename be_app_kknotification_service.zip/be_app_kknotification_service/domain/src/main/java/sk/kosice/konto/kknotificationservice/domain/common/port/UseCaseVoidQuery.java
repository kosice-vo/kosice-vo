package sk.kosice.konto.kknotificationservice.domain.common.port;

public interface UseCaseVoidQuery<O> {

  O execute();
}
