package sk.kosice.konto.kknotificationservice.domain.common.port;

import sk.kosice.konto.kknotificationservice.domain.common.marker.Command;

public interface UseCaseVoidCommand<C extends Command> {

  void execute(C command);
}
