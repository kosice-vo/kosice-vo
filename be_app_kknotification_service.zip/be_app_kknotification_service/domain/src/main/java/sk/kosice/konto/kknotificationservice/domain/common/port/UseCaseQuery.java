package sk.kosice.konto.kknotificationservice.domain.common.port;

import sk.kosice.konto.kknotificationservice.domain.common.marker.Query;

public interface UseCaseQuery<Q extends Query, O> {

  O execute(Q query);
}
