package sk.kosice.konto.kknotificationservice.domain.common.marker;

public interface Query {}
