package sk.kosice.konto.kknotificationservice.domain.message.entity;

import java.util.Optional;
import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kkmessageservice.domain.common.enumeration.BodyType;

@Value.Immutable
@Value.Style(stagedBuilder = true)
public interface MessageEntity extends BaseMessageEntity {

  String body();

  Optional<UUID> recipientKid();

  Boolean isNotificationSend();

  BodyType bodyType();

  String bodyShort();

  UUID topicId();

  Optional<String> actions();
}
