package sk.kosice.konto.kknotificationservice.domain.common.marker;

import java.util.Optional;
import sk.kosice.konto.kknotificationservice.domain.common.ActorIdentity;

public interface AuditableQuery extends Query {

  /**
   * Identity of logged person who performed action.
   *
   * @return Identity of actor.
   */
  Optional<ActorIdentity> actorId();
}
