package sk.kosice.konto.kknotificationservice.domain.permission.command;

import org.immutables.value.Value;
import sk.kosice.konto.kknotificationservice.domain.common.marker.Command;
import sk.kosice.konto.kknotificationservice.domain.shared.enumeration.Permission;

@Value.Immutable
public interface CheckPermissionCommand extends Command {

  String actorId();

  Permission permissionToCheck();
}
