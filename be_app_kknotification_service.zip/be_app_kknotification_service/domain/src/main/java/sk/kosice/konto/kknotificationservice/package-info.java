@Value.Style(stagedBuilder = true)
package sk.kosice.konto.kknotificationservice;

import org.immutables.value.Value;
