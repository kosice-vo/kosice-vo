package sk.kosice.konto.kknotificationservice.domain.permission.entity;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import sk.kosice.konto.kkmessageservice.domain.organization.entity.OrganizationEntity;
import sk.kosice.konto.kknotificationservice.domain.shared.enumeration.Permission;

public record ListOfPermissions(UUID userId, Map<OrganizationEntity, Set<Permission>> items) {}
