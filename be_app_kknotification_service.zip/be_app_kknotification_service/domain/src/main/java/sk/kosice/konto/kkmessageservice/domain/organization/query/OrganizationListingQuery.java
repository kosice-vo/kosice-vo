package sk.kosice.konto.kkmessageservice.domain.organization.query;

import java.util.Optional;
import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kknotificationservice.domain.common.marker.Query;

@Value.Immutable
public interface OrganizationListingQuery extends Query {
  Optional<UUID> rootOrganizationId();
}
