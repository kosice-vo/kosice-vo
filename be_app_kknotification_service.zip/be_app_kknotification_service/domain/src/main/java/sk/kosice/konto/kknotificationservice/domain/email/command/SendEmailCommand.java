package sk.kosice.konto.kknotificationservice.domain.email.command;

import java.util.List;
import org.immutables.value.Value;
import sk.kosice.konto.kknotificationservice.domain.common.marker.Command;
import sk.kosice.konto.kknotificationservice.domain.email.entity.SenderInfo;
import sk.kosice.konto.kknotificationservice.domain.shared.enumeration.EmailBodyType;

@Value.Immutable
public interface SendEmailCommand extends Command {

  String messageTitle();

  String messageBody();

  EmailBodyType messageBodyType();

  SenderInfo senderInfo();

  List<String> recipients();
}
