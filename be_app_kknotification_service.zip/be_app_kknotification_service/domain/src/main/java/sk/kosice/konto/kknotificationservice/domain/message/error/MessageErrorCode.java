package sk.kosice.konto.kknotificationservice.domain.message.error;

import static sk.kosice.konto.kknotificationservice.domain.common.error.ErrorCodeType.NOT_FOUND;

import sk.kosice.konto.kknotificationservice.domain.common.error.ErrorCode;
import sk.kosice.konto.kknotificationservice.domain.common.error.ErrorCodeType;

public enum MessageErrorCode implements ErrorCode {
  MESSAGE_DOES_NOT_EXIST(NOT_FOUND, "Message with id '%s' does not exist.");

  private final ErrorCodeType type;
  private final String template;

  MessageErrorCode(ErrorCodeType type, String template) {
    this.type = type;
    this.template = template;
  }

  @Override
  public String template() {
    return this.template;
  }

  @Override
  public ErrorCodeType type() {
    return this.type;
  }
}
