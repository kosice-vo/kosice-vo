package sk.kosice.konto.kknotificationservice.domain.common.port;

public interface UseCaseVoidVoid {

  void execute();
}
