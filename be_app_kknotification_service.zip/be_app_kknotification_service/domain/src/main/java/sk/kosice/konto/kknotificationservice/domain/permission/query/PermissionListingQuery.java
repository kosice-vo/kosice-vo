package sk.kosice.konto.kknotificationservice.domain.permission.query;

import java.util.UUID;
import org.immutables.value.Value;
import sk.kosice.konto.kknotificationservice.domain.common.marker.Query;

@Value.Immutable
public interface PermissionListingQuery extends Query {

  UUID userId();
}
