package sk.kosice.konto.kknotificationservice.domain.shared.enumeration;

public enum Role {
  ADMIN("Admin");

  private final String name;

  Role(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }
}
