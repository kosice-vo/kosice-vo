package sk.kosice.konto.kknotificationservice.domain.shared.enumeration;

import java.util.List;

public enum Permission {
  ACTION_MANAGE_RECIPIENT(Role.ADMIN);

  private final List<Role> roles;

  Permission(Role... roles) {
    this.roles = List.of(roles);
  }

  public List<Role> getRoles() {
    return roles;
  }
}
