package sk.kosice.konto.kknotificationservice.domain.shared.enumeration;

public enum EmailBodyType {
  TEXT,
  HTML
}
