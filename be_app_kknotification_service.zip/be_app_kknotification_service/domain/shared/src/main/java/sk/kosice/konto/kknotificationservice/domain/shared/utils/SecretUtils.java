package sk.kosice.konto.kknotificationservice.domain.shared.utils;

import java.nio.file.Files;
import java.nio.file.Paths;

public class SecretUtils {

  public static String resolveSecretValue(String value) {
    try {
      return Files.readString(Paths.get(value)).trim();
    } catch (Exception ignored) {
      return value;
    }
  }
}
