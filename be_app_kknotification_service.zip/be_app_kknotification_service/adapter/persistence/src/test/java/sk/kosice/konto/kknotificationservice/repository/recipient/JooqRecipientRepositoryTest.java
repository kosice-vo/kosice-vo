package sk.kosice.konto.kknotificationservice.repository.recipient;

import sk.kosice.konto.kknotificationservice.repository.JooqRepositoryTest;

public abstract class JooqRecipientRepositoryTest extends JooqRepositoryTest
    implements JooqRecipientRepositoryTestSupport {}
