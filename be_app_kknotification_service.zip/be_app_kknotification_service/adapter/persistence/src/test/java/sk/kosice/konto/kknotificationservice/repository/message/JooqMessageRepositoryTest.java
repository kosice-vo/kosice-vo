package sk.kosice.konto.kknotificationservice.repository.message;

import sk.kosice.konto.kknotificationservice.repository.JooqRepositoryTest;

public abstract class JooqMessageRepositoryTest extends JooqRepositoryTest
    implements JooqMessageRepositoryTestSupport {}
