package sk.kosice.konto.kknotificationservice.repository.message;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

import org.junit.jupiter.api.Test;

public class JooqMessageRepositoryFindTest extends JooqMessageRepositoryTest {

  @Test
  public void thatNotSentMessagesCanBeRetrieved() {
    insertMessages(dslContext);

    final var messages = findMessagesWasNotSent(messageRepository);
    assertThat(messages).isNotNull();
    assertThat(messages.size()).isEqualTo(2);
  }
}
