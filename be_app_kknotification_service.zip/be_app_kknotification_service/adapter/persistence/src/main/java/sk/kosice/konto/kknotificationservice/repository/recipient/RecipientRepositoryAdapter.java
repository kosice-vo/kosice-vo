package sk.kosice.konto.kknotificationservice.repository.recipient;

import sk.kosice.konto.kknotificationservice.business.recipient.port.outbound.PersistRecipientPort;
import sk.kosice.konto.kknotificationservice.business.recipient.port.outbound.QueryRecipientPort;

public interface RecipientRepositoryAdapter extends PersistRecipientPort, QueryRecipientPort {}
