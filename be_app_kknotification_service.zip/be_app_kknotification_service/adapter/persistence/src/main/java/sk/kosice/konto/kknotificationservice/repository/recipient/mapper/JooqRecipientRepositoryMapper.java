package sk.kosice.konto.kknotificationservice.repository.recipient.mapper;

import org.jooq.RecordMapper;
import sk.kosice.konto.kkmessageservice.repository.model.tables.records.RecipientRecord;
import sk.kosice.konto.kknotificationservice.domain.recipient.entity.ImmutableRecipientEntity;
import sk.kosice.konto.kknotificationservice.domain.recipient.entity.RecipientEntity;

public final class JooqRecipientRepositoryMapper {

  public static RecordMapper<RecipientRecord, RecipientEntity> recipientRecordMapper() {
    return record ->
        ImmutableRecipientEntity.builder().kid(record.getKid()).email(record.getEmail()).build();
  }
}
