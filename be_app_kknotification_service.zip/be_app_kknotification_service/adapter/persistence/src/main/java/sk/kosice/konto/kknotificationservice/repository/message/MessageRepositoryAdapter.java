package sk.kosice.konto.kknotificationservice.repository.message;

import sk.kosice.konto.kknotificationservice.business.message.port.outbound.PersistMessagePort;
import sk.kosice.konto.kknotificationservice.business.message.port.outbound.QueryMessagePort;

public interface MessageRepositoryAdapter extends PersistMessagePort, QueryMessagePort {}
