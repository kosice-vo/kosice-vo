package sk.kosice.konto.kknotificationservice.restapi.config;

public interface OAuthPropertiesPort {

  String ocAppIntegrationIssuerLocation();

  String ocAppIntegrationJwksUrl();
}
