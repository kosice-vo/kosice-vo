package sk.kosice.konto.kknotificationservice.restapi.common.enumeration;

public enum Platform {
  WEB,
  MOBILE,
  DESKTOP,
  SERVER
}
