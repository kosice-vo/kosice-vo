package sk.kosice.konto.kknotificationservice.restapi.mapper;

import sk.kosice.konto.kknotificationservice.domain.recipient.entity.RecipientEntity;
import sk.kosice.konto.kknotificationservice.restapi.dto.recipient.ImmutableRecipientDetailResponse;
import sk.kosice.konto.kknotificationservice.restapi.dto.recipient.RecipientDetailResponse;

public final class RecipientResponseMapper {

  public static RecipientDetailResponse map(RecipientEntity entity) {
    return ImmutableRecipientDetailResponse.builder()
        .preferredEmail(entity.email())
        .kid(entity.kid())
        .build();
  }
}
