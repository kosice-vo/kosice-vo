package sk.kosice.konto.kknotificationservice.restapi.dto.recipient;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.util.UUID;
import org.immutables.value.Value;

@JsonDeserialize(as = ImmutableRecipientDetailResponse.class)
@JsonSerialize(as = ImmutableRecipientDetailResponse.class)
@Value.Immutable
public interface RecipientDetailResponse extends CreateOrUpdateRecipientRequest {

  UUID kid();
}
