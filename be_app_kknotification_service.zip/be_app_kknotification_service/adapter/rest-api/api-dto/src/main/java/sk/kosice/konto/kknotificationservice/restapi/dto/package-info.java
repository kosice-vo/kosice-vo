package sk.kosice.konto.kknotificationservice.restapi.dto;
