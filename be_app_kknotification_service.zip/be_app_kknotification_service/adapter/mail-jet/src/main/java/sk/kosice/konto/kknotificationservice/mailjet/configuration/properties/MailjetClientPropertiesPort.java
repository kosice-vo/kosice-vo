package sk.kosice.konto.kknotificationservice.mailjet.configuration.properties;

public interface MailjetClientPropertiesPort {

  String apiKey();

  String secretKey();
}
