# kknotification micro-service

# Create DB tables
Before build run commnad in kkmessage service
```shell script
bin/with_env_vars.sh update  # Unix-like
bin\with_env_vars.bat update # Windows
```
# Build
```shell script
bin/build.sh  # Unix-like
bin\build.bat # Windows
```
# Run
```shell script
bin/with_env_vars.sh bootRun  # Unix-like
bin\with_env_vars.bat bootRun # Windows
```
# Swagger UI
http://localhost:8080/internal/swagger-ui/index.html
