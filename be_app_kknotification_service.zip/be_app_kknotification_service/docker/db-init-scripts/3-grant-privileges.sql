BEGIN;

GRANT USAGE ON SCHEMA kk_message_data TO kkmessage_user, kknotification_user;
GRANT CREATE ON SCHEMA kk_message_data TO kkmessage_user, kknotification_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA kk_message_data TO kkmessage_user, kknotification_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA kk_message_data TO kkmessage_user, kknotification_user;

COMMIT
