package sk.kosice.konto.kknotificationservice.business.recipient.port.outbound;

import java.util.List;
import java.util.UUID;
import sk.kosice.konto.kknotificationservice.domain.common.error.BusinessException;
import sk.kosice.konto.kknotificationservice.domain.recipient.entity.RecipientEntity;

public interface QueryRecipientPort {

  RecipientEntity findOne(UUID kid) throws BusinessException;

  List<RecipientEntity> list();

  List<RecipientEntity> listByTopic(UUID topicId);
}
