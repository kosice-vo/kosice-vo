package sk.kosice.konto.kknotificationservice.business.message.port.inbound;

import sk.kosice.konto.kknotificationservice.domain.common.port.UseCaseVoidCommand;
import sk.kosice.konto.kknotificationservice.domain.message.command.MarkMessageAsSentCommand;

public interface MarkMessageAsSentUseCase extends UseCaseVoidCommand<MarkMessageAsSentCommand> {}
