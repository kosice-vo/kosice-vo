package sk.kosice.konto.kknotificationservice.business.message.port.outbound;

import java.util.List;
import java.util.UUID;
import sk.kosice.konto.kknotificationservice.domain.message.entity.MessageEntity;

public interface QueryMessagePort {

  List<MessageEntity> findNotSentMessages(int limit);

  void markMessageAsSent(UUID messageId);
}
