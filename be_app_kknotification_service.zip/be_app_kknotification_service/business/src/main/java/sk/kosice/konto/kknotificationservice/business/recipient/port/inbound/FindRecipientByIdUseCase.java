package sk.kosice.konto.kknotificationservice.business.recipient.port.inbound;

import sk.kosice.konto.kknotificationservice.domain.common.port.UseCaseQuery;
import sk.kosice.konto.kknotificationservice.domain.recipient.entity.RecipientEntity;
import sk.kosice.konto.kknotificationservice.domain.recipient.query.FindRecipientByIdQuery;

public interface FindRecipientByIdUseCase
    extends UseCaseQuery<FindRecipientByIdQuery, RecipientEntity> {}
