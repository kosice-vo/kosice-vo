package sk.kosice.konto.kknotificationservice.business.permission.port.inbound;

import sk.kosice.konto.kknotificationservice.domain.common.port.UseCaseQuery;
import sk.kosice.konto.kknotificationservice.domain.permission.entity.ListOfPermissions;
import sk.kosice.konto.kknotificationservice.domain.permission.query.PermissionListingQuery;

public interface ListPermissionUseCase
    extends UseCaseQuery<PermissionListingQuery, ListOfPermissions> {}
