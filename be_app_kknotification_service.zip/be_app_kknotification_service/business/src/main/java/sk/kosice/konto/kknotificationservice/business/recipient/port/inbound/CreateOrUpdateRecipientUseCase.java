package sk.kosice.konto.kknotificationservice.business.recipient.port.inbound;

import sk.kosice.konto.kknotificationservice.domain.common.port.UseCaseCommand;
import sk.kosice.konto.kknotificationservice.domain.recipient.command.CreateOrUpdateRecipientCommand;
import sk.kosice.konto.kknotificationservice.domain.recipient.entity.RecipientEntity;

public interface CreateOrUpdateRecipientUseCase
    extends UseCaseCommand<CreateOrUpdateRecipientCommand, RecipientEntity> {}
