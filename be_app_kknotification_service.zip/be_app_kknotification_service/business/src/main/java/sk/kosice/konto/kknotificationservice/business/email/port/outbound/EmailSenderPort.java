package sk.kosice.konto.kknotificationservice.business.email.port.outbound;

import sk.kosice.konto.kknotificationservice.domain.common.error.BusinessException;
import sk.kosice.konto.kknotificationservice.domain.email.command.SendEmailCommand;

public interface EmailSenderPort {

  void sendEmail(SendEmailCommand command) throws BusinessException;
}
