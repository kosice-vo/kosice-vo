package sk.kosice.konto.kknotificationservice.business.email.port.inbound;

import sk.kosice.konto.kknotificationservice.domain.common.port.UseCaseConvertCommand;
import sk.kosice.konto.kknotificationservice.domain.email.command.SendEmailCommand;
import sk.kosice.konto.kknotificationservice.domain.message.entity.MessageEntity;

public interface CreateEmailFromMessageUseCase
    extends UseCaseConvertCommand<MessageEntity, SendEmailCommand> {}
