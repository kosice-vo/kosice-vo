package sk.kosice.konto.kknotificationservice.business.permission.port.outbound;

import sk.kosice.konto.kknotificationservice.domain.common.port.UseCaseCommand;
import sk.kosice.konto.kknotificationservice.domain.permission.command.CheckPermissionCommand;

public interface CheckPermissionsUseCase extends UseCaseCommand<CheckPermissionCommand, Boolean> {}
