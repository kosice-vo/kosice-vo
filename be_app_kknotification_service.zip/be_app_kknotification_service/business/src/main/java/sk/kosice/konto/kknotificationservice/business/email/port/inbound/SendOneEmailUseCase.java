package sk.kosice.konto.kknotificationservice.business.email.port.inbound;

import sk.kosice.konto.kknotificationservice.domain.common.port.UseCaseVoidCommand;
import sk.kosice.konto.kknotificationservice.domain.email.command.SendEmailCommand;

public interface SendOneEmailUseCase extends UseCaseVoidCommand<SendEmailCommand> {}
