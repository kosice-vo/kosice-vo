package sk.kosice.konto.kknotificationservice.business.recipient.port.outbound;

import sk.kosice.konto.kknotificationservice.domain.common.error.BusinessException;
import sk.kosice.konto.kknotificationservice.domain.recipient.entity.RecipientEntity;

public interface PersistRecipientPort {

  void merge(RecipientEntity data) throws BusinessException;
}
