package sk.kosice.konto.kknotificationservice.business.message.port.outbound;

import java.util.UUID;

public interface PersistMessagePort {
  void markMessageAsSent(UUID messageId);
}
