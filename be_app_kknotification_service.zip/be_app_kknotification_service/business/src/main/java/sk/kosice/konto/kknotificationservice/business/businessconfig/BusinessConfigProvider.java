package sk.kosice.konto.kknotificationservice.business.businessconfig;

import sk.kosice.konto.kknotificationservice.domain.businessconfig.BusinessConfig;

public class BusinessConfigProvider {

  private final BusinessConfig businessConfig;

  public BusinessConfigProvider(BusinessConfig businessConfig) {
    this.businessConfig = businessConfig;
  }

  public BusinessConfig getBusinessConfig() {
    return businessConfig;
  }
}
