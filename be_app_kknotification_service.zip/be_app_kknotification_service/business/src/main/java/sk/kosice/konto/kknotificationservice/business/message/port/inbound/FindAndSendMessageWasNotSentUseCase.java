package sk.kosice.konto.kknotificationservice.business.message.port.inbound;

import sk.kosice.konto.kknotificationservice.domain.common.port.UseCaseVoidVoid;

// Called by scheduler
public interface FindAndSendMessageWasNotSentUseCase extends UseCaseVoidVoid {

  // Use Port for do select from db
  // Call CreateEmailFromMessageUseCase for creating emails
  // Call SendOneEmailUseCase for send email

  // If message will not personalized (doesn't have KID) will be called
  // different UseCase. with filters and others stuff. will be other UserStory
}
