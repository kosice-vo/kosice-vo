package sk.kosice.konto.kknotificationservice.message;

public final class MessageApiFixtures {}
