package sk.kosice.konto.kknotificationservice.recipient;

import sk.kosice.konto.kknotificationservice.restapi.dto.recipient.ImmutableCreateOrUpdateRecipientRequest;

public final class RecipientApiFixtures {

  public static ImmutableCreateOrUpdateRecipientRequest createOrUpdateRecipientRequest() {
    return ImmutableCreateOrUpdateRecipientRequest.builder()
        .preferredEmail("jozef.kosicky@icloud.com")
        .build();
  }
}
