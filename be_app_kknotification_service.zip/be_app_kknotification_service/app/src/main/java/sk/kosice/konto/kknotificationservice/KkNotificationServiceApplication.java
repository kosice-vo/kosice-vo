package sk.kosice.konto.kknotificationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jooq.JooqAutoConfiguration;
import sk.kosice.konto.kkmessageservice.idp.AzureIdpRepository;

@SpringBootApplication(
    scanBasePackageClasses = {KkNotificationServiceApplication.class, AzureIdpRepository.class},
    exclude = {JooqAutoConfiguration.class, DataSourceAutoConfiguration.class})
public class KkNotificationServiceApplication {
  public static void main(String[] args) {
    SpringApplication.run(KkNotificationServiceApplication.class);
  }
}
