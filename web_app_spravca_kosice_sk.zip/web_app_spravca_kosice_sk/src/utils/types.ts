export type RGB = {
  r: number;
  g: number;
  b: number;
};

export type SessionError = 'OrganizationError' | 'NoOrganizationError' | 'MissingTokenError' | 'RefreshTokenError';
