export type Color = {
  name: string;
  value: string;
};

export const COLORS: Color[] = [
  {
    name: 'Modrá',
    value: '#126DFF'
  },
  {
    name: 'Červená',
    value: '#C3112B'
  },
  {
    name: 'Zelená',
    value: '#078814'
  },
  {
    name: 'Hnedá',
    value: '#BD730C'
  },
  {
    name: 'Olivová',
    value: '#727B0F'
  },
  {
    name: 'Mätová',
    value: '#1E856D'
  },
  {
    name: 'Fialová',
    value: '#9544FF'
  },
  {
    name: 'Ružová',
    value: '#CF06C8'
  },
  {
    name: 'Čierna',
    value: '#212121'
  },
  {
    name: 'Tyrkysová',
    value: '#02C4DE'
  },
  {
    name: 'Oranžová',
    value: '#FFAB2F'
  },
  {
    name: 'Tehlová',
    value: '#FF573B'
  }
];
