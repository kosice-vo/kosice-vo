import React from 'react';

const OrganizationsListSkeleton: React.FC = () => {
  return (
    <div>
      {Array.from({ length: 12 }).map((_, index) => (
        <div
          key={index}
          className="animate-pulse w-full h-12 flex py-3 px-4 rounded-md justify-between items-center bg-neutral-300 mb-3"
        />
      ))}
    </div>
  );
};

export default OrganizationsListSkeleton;
