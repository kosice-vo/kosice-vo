'use client';

import axios from 'axios';
import { withPermission } from '@/components';
import { useParams, useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import { useQuery } from '@tanstack/react-query';
import { api, date, Message, MessageTag as MessageTagType, RequestError, unwrap } from '@/utils';
import { MessageBody, Error, MessageSkeleton, MessageTag, QueryHandler } from '@/components';
import { ArrowBackIcon, HorizontalNavigation, HorizontalNavigationItem } from '@/lib/idsk';

const MessageDetailPage = () => {
  const params = useParams();
  const { id } = params;
  const { data } = useSession();
  const router = useRouter();

  const query = useQuery<Message, RequestError>({
    queryKey: ['message', id],
    queryFn: () => unwrap(axios.get(`/api${api.messageDetail(data?.user.organization?.id || '', id as string)}`))
  });

  return (
    <>
      <HorizontalNavigation className="mb-7 w-fit">
        <HorizontalNavigationItem icon={<ArrowBackIcon />} onClick={() => router.back()}>
          Späť
        </HorizontalNavigationItem>
      </HorizontalNavigation>
      <QueryHandler query={query} loading={<MessageSkeleton />} error={<Error err={query.error} />}>
        {(detail) => (
          <div className="bg-white w-full border border-neutral-300 rounded-lg idsk-text-body">
            <div className="p-5 border-b border-neutral-300">
              <div className="flex justify-between gap-5">
                <h3>{detail.title}</h3>
                <span>{date(detail.createdAt)}</span>
              </div>
              <p className="mt-2">
                <b>Prijímateľ: </b>
                <span>{detail.recipientKid ? `Občan s KID: ${detail.recipientKid}` : 'Všetci'}</span>
              </p>
              <p className="mt-2">
                <b>Typ: </b>
                <span>{detail.recipientKid ? 'Personalizovaná správa' : 'Všeobecná správa'}</span>
              </p>
              {detail.tags?.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-5">
                  {detail.tags.map((tag: MessageTagType, index: number) => (
                    <MessageTag key={`tag-${tag.color}-${tag.value}-${index + 1}`} color={tag.color} size="small">
                      {tag.value}
                    </MessageTag>
                  ))}
                </div>
              )}
            </div>
            <MessageBody body={detail.body} actions={detail.actions} />
          </div>
        )}
      </QueryHandler>
    </>
  );
};

export default withPermission(MessageDetailPage, 'ACTION_MANAGE_MESSAGE');
