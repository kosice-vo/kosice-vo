import { auth } from '@/auth';

export async function GET() {
  const session = await auth();

  if (!session) {
    return new Response('Permission denied.', { status: 403 });
  }

  return Response.json({ session });
}
