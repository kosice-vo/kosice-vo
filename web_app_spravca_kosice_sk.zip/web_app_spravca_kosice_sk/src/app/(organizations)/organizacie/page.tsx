import { OrganizationsList } from '@/components';

const OrganizationsPage = () => {
  return (
    <div className="max-w-[28rem] mx-auto mt-[9rem]">
      <h4 className="text-center mb-7">Výber subjektu pre zastupovanie</h4>
      <OrganizationsList />
    </div>
  );
};

export default OrganizationsPage;
