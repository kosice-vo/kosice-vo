'use client';

import React, { useEffect } from 'react';
import { signOut } from 'next-auth/react';

const LogoutPage: React.FC = () => {
  useEffect(() => {
    signOut({ callbackUrl: '/prihlasenie' });
  }, []);

  return null;
};

export default LogoutPage;
